# @gaston/auth

Núcleo reutilizable de autenticación y autorización, independiente de la interfaz visual. La versión `0.2.0` ofrece contratos genéricos, estado observable de sesión, permisos y un adaptador para Firebase Authentication.

## Alcance

- Inicio de sesión con correo y contraseña.
- Cierre de sesión y recuperación de contraseña.
- Estado de sesión (`initializing`, `authenticated`, `unauthenticated` o `error`).
- Roles, permisos y guards agnósticos de React.
- Errores públicos normalizados, sin mensajes internos del proveedor.
- Contrato `AuthProvider` para sustituir Firebase o usar fakes en pruebas.

## Instalación y dependencias

Dentro de este monorepo:

```bash
npm install
```

Cuando se habilite la publicación privada, el proyecto consumidor instalará el paquete junto con su peer dependency:

```bash
npm install @gaston/auth firebase
```

Firebase es una `peerDependency`: la aplicación controla su versión compatible y la instancia configurada. React no es una dependencia.

## Integración con Firebase

El proyecto consumidor inicializa Firebase y entrega la instancia `Auth`. El módulo nunca crea una aplicación, lee variables de entorno ni contiene credenciales.

```ts
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { AuthService, FirebaseAuthProvider } from "@gaston/auth";

const app = initializeApp(firebaseConfig);
const firebaseAuth = getAuth(app);
const provider = new FirebaseAuthProvider(firebaseAuth);
const auth = new AuthService(provider);
```

Por defecto, el adaptador crea usuarios sin roles ni permisos. Un proyecto puede inyectar `mapUser` para enriquecer el usuario con claims ya obtenidos o metadata propia, sin acoplar el core a esa estrategia:

```ts
const provider = new FirebaseAuthProvider(firebaseAuth, {
  mapUser: (user) => ({
    id: user.uid,
    email: user.email,
    ...(user.displayName === null ? {} : { displayName: user.displayName }),
    roles: [],
    permissions: [],
    metadata: { provider: "firebase" },
  }),
});
```

## Login, logout y recuperación

```ts
try {
  const user = await auth.signIn({
    email: "persona@example.com",
    password: formPassword,
  });
  console.log(user.id);
} catch (error) {
  if (error instanceof AuthError) {
    showSafeMessage(error.code);
  }
}

await auth.sendPasswordReset({ email: "persona@example.com" });
await auth.signOut();
```

## Estado de sesión y UI personalizada

La UI pertenece a la aplicación. Cualquier framework puede observar el estado y representar su propia pantalla:

```ts
const unsubscribe = auth.onSessionStateChanged((state) => {
  if (state.status === "initializing") renderLoading();
  if (state.status === "authenticated") renderApplication(state.user);
  if (state.status === "unauthenticated") renderCustomLogin();
});

// Al desmontar o terminar la aplicación:
unsubscribe();
auth.dispose();
```

## Roles, permisos y acceso

```ts
import { canAccess, hasPermission, requirePermission } from "@gaston/auth";

if (hasPermission(user, "invoices:read")) {
  showInvoices();
}

const mayEdit = canAccess(user, {
  roles: ["admin", "editor"],
  permissions: ["articles:write"],
});

requirePermission(user, "articles:publish"); // AuthError(access-denied) si no cumple
```

Los nombres de roles y permisos son cadenas definidas por cada aplicación; el módulo no incorpora reglas comerciales.

## Qué no hace el módulo

No incluye UI, registro público, login social, MFA, captcha, Firestore, gestión de clientes, almacenamiento de secretos ni sincronización de usuarios entre proyectos. Tampoco decide cómo se asignan roles y permisos.

## Estrategia futura

Las siguientes versiones podrán incorporar adaptadores adicionales, claims asíncronos, integración opcional con frameworks y flujos avanzados. Cada capacidad seguirá detrás de contratos públicos pequeños. El paquete no se publicará hasta que exista autorización y un proceso privado de release.
